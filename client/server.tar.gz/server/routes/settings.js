import express from 'express';
import db from '../db.js';
import { verifyAdmin } from '../middleware/auth.js';

const router = express.Router();

// Get settings
router.get('/', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM settings WHERE id = $1', ['default']);
    const settings = result.rows[0] || { id: 'default', whatsapp_number: '', store_name: 'Paint Connect' };
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update settings (admin only)
router.put('/', verifyAdmin, async (req, res) => {
  try {
    const { whatsapp_number, store_name } = req.body;

    const result = await db.query(
      'UPDATE settings SET whatsapp_number = $1, store_name = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3 RETURNING *',
      [whatsapp_number, store_name, 'default']
    );

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
